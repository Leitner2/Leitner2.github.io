''' Exercise #2. Python for Engineers.'''

#########################################
# Question 1 - do not delete this comment
#########################################
D = 3  # Replace the assignment with a postive integer to test your code.
A = []
# Write the rest of the code for question 1 below here.






# End of code for question 1
#### do not delete the next line ###
assert isinstance(A, list)


#########################################
# Question 2 - do not delete this comment
#########################################

b = 3  # Replace the assignment with a postive integer to test your code.
B = [1, 2, 3, 4, 5] # Replace the assignment with other lists to test your code.


# Write the rest of the code for question 2 below here.



# End of code for question 2



#########################################
# Question 3 - do not delete this comment
#########################################

C = [0, 1, 2, 3, 4] # Replace the assignment with other lists to test your code.


# Write the rest of the code for question 3 below here.




# End of code for question 3


#########################################
# Question 4 - do not delete this comment
#########################################

N = 17  # Replace the assignment with a postive integer > 1, to test your code.

# Write the rest of the code for question 4 below here.




# End of code for question 4


#########################################
# Question 5 - do not delete this comment
#########################################

E = [2, 4, 6] # Replace the assignment with other strings to test your code.


# Write the rest of the code for question 5 below here.





# End of code for question 5


#########################################
# Question 6 - do not delete this comment
#########################################

str_list = ["The RED ball", "A RED ball", "A red ball", "FRED", "AAA RED"] # Replace the assignment with other lists to test your code.

str_list_RED = []
# Write the rest of the code for question 6 below here.





# End of code for question 6
#### do not delete the next line ###
assert isinstance(str_list_RED, list)